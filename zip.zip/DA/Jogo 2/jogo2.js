var segundos=5;
var conta;
var contadorRandom=0;
var numeroRandom;
var nome1;
var nome2;
var repeticoes;
var i=1;
var conta2;
var audio=new Audio("musicas/contagem.mp3");
var audio2=new Audio("musicas/amor.mp3");
var audio3=new Audio("musicas/mau.mp3");
var audio4=new Audio("musicas/muito mau.mp3");
var h=0;
var repeticoes1;


//FRASE FINAL
function visualizar2(){
    document.querySelector("button").setAttribute("class", "visivel");
    document.querySelector("button").textContent="Jogar outra vez";
    if(numeroRandom<30) document.querySelector("#temporiza").innerHTML=document.querySelector("#temporiza").innerHTML+"<br> Segundo as nossas pesquisas ," + nome1+" e "+nome2+", não foram feitos um para o outro.";
    else{ if (numeroRandom<50) document.querySelector("#temporiza").innerHTML=document.querySelector("#temporiza").innerHTML+"<br>Segundo as nossas pesquisas ," + nome1+" e "+nome2+", não se vão dar bem, mas podem tentar.";
        else{ if (numeroRandom<70) document.querySelector("#temporiza").innerHTML=document.querySelector("#temporiza").innerHTML+"<br>Segundo as nossas pesquisas ," + nome1+" e "+nome2+", foram feitos um para o outro!";
            else{ if (numeroRandom<90) document.querySelector("#temporiza").innerHTML=document.querySelector("#temporiza").innerHTML+"<br>Segundo as nossas pesquisas ," + nome1+" e "+nome2+", são almas gémeas!";
                else{ document.querySelector("#temporiza").innerHTML=document.querySelector("#temporiza").innerHTML+"<br>Segundo as nossas pesquisas ," + nome1+" e "+nome2+", são o par perfeito.<br> Parábens encontraram a vossa alma gémea!";}
            }
        }
    }
}

//CHAMADA DA PROBABILIDADE
function visualizar(numeroRandom){
    repeticoes=setInterval(contagem, 100);
}

//PROBABILIDADE CRESCENTE
function contagem(){
    if(nome1==nome2) numeroRandom=100;

    if(i<=(numeroRandom/1.5)){
        document.querySelector("#temporiza").innerHTML="Probabilidade de resultar<br>"+i+"%";
        i++;
    }
    else{
         clearInterval(repeticoes);
         visualizar3();
    }
}
function visualizar3(){
    conta2=setInterval(visualizar4, 200);
}
function visualizar4(){
    if(numeroRandom>50) audio2.play();
    else{
        if(numeroRandom<25) audio4.play();
        else audio3.play();
    }
    if(i<=numeroRandom/1.1){
        document.querySelector("#temporiza").innerHTML="Probabilidade de resultar<br>"+i+"%";
        i++;
    }
    else{
        clearInterval(conta2);
        visualizar5();

    }
}
function visualizar5(){
    repeticoes1=setInterval(visualizar6,400);
}
function visualizar6(){
        if(i<=numeroRandom){
            document.querySelector("#temporiza").innerHTML="Probabilidade de resultar<br>"+i+"%";
            i++;
        }
        else{
            clearInterval(repeticoes1);
            i=1;
            setTimeout("visualizar2()",3000);
        }
    
}
//GERAR NUMERO RANDOM
function gerar(){
    contadorRandom++;
    if (contadorRandom%3==0)  numeroRandom=Math.floor((Math.random()*49)+1); 
    else numeroRandom=Math.floor((Math.random()*49)+50);
    console.log(numeroRandom);
    visualizar(numeroRandom);
}

//CONTAGEM PARA RESULTADO
function contador(){
    conta= setInterval(tempo,1900);
}

//SEGUNDOS
function tempo(){
    audio.play();
    if(segundos==0){
        clearInterval(conta);
        segundos=6;
        setTimeout("gerar()", 1000);
    }
    else document.querySelector("div#temporiza").innerHTML=segundos;
    segundos--;

}
//INPUT
function resposta(){
    
    audio2.pause();
    audio3.pause();
    audio4.pause();
    if(document.querySelectorAll("input")[0].value=="" || document.querySelectorAll("input")[1].value=="") alert("Preecha os campos");
    else{
        if(h!=0 && document.querySelectorAll("input")[0].value==nome1 && document.querySelectorAll("input")[1].value==nome2){
                alert("Selecione nomes diferentes");
            }
        else{
            document.querySelector("button").setAttribute("class", "invisivel");
            contador();
            nome1=document.querySelectorAll("input")[0].value;
            nome2=document.querySelectorAll("input")[1].value;
        }
        h++;
    }
}

//DATA
function data() {
    var data = new Date();
    var horas = data.getHours();
    var minuto = data.getMinutes();
    var segundo = data.getSeconds();
    var dia= data.getDay()+6;
    var mes= data.getMonth();
    minuto=zeroMais(minuto);
    segundo=zeroMais(segundo);
    dia=zeroMais(dia);
    document.querySelector("#horas").innerHTML ="<br>"+ horas + ":" + minuto + ":" + segundo +"<br>"+ dia +"/"+mes+ 1 +"/"+data.getUTCFullYear();
    

}

//ACRESCENTAR ZEROS
  function zeroMais(i) {
    if(i<10) i="0"+i
    return i;
  }

  setInterval("data()",500);