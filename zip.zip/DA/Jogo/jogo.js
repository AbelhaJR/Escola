//DEFENIÇÃO VARIAVEIS
var numeroRandom;
var repeticao;
var segundos = 0;
var contador = 0;

//FUNÇÕES

  //DATA
function horasReal() {
  var data = new Date();
  var horas = data.getHours();
  var minuto = data.getMinutes();
  var segundo = data.getSeconds();
  minuto=zeroMais(minuto);
  segundo=zeroMais(segundo)
  document.querySelector("div.horas").innerHTML = horas + ":" + minuto + ":" + segundo;
  setTimeout(horasReal, 500);
}
function zeroMais(i){
  if(i<10) i="0"+i
  return i;
}
  //VERIFICAR O NUMERO
function verificar(numeroRandom) {
  document.querySelector("button").textContent="Jogar outra vez";
  document.querySelector("button").classList.toggle("butao2");
  if (numeroRandom < 50) document.getElementById("resposta").innerHTML = "Segundo os nossos resultados o " + document.getElementById("crush1").value + " e a " + document.getElementById("crush2").value + " não se vão dar bem <br /> Probabilidade de resultar= " + numeroRandom + "%";
  else document.getElementById("resposta").innerHTML = "Segundo os nossos resultados o " + document.getElementById("crush1").value + " e a " + document.getElementById("crush2").value + " vão se dar bem <br /> Probabilidade de resultar= " + numeroRandom + "%";
}
  //GERAR
function gerar() {
  contador++;
  if (contador % 5 == 0) numeroRandom = Math.floor((Math.random() * 48) + 1);
  else numeroRandom = Math.floor((Math.random() * 48) + 50);
  verificar(numeroRandom);
}
  //VERIFICAR CONTAGEM
function numero() {
  segundos++;
  if (segundos <= 3) document.getElementById("resposta").innerHTML = segundos;
  else {
    clearInterval(repeticao);
    segundos = 0;
    gerar();
  }
}
  //CONTAGEM
function tempo ()  {
  if (document.getElementById("crush2").value == "" || document.getElementById("crush1").value == "") alert("Preencha os campos");
  else{
    repeticao = setInterval(numero, 1000);
    document.querySelector("button").classList.add("butao2");
    console.log(document.querySelector("button").classList);

  } 
}
