var numeros;
var resultado=0;
var sinal="";
var limpa=0;
var numerosreais;
for(var i=0;i<document.querySelectorAll("td#numeros").length;i++){
    document.querySelectorAll("td#numeros")[i].addEventListener("click", function(){
        if(limpa==0){
        document.getElementById("visor").innerHTML=document.getElementById("visor").innerHTML+this.innerHTML;
        }
        else{
            document.getElementById("visor").innerHTML=this.innerHTML;
            limpa=0;
        }
        numeros=this.innerHTML;
    });
}
for(var i=0;i<document.querySelectorAll("td#sinal").length;i++){
    document.querySelectorAll("td#sinal")[i].addEventListener("click",function(){
        limpa=1;
        if(sinal!=""){
            numerosreais=parseInt(numeros);
            switch(sinal){
                case "+":
                    resultado+=numerosreais;
                    break;
                case "-":
                    resultado-=numerosreais;
                    break;
                case "/":
                    resultado/=numerosreais;
                    break;
                case "*":
                    resultado*=numerosreais;       
                    break;
            }
            sinal=this.innerHTML;
            document.getElementById("visor").innerHTML=resultado;
        }
        else{
            sinal=this.innerHTML;
            resultado=parseInt(numeros);
        }
    });
}
