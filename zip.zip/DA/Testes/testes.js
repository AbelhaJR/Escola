var t=50;

$("body").on("keypress",function(event){
    $("h1").append(event.key);
})