#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int number, vezes1=0 ,vezes2=0, vezes3=0, vezes4=0,maior=-9,menor=9999,maior2=-9,diferenca;
	cin>>number;
	string final;
	int vetor[number];
	for(int i=0;i<number;i++){
		cin>>vetor[i];
		if(vetor[i]<menor) menor=vetor[i];
		if(vetor[i]>maior) maior=vetor[i];
		if(vetor[i]>=1 && vetor[i]<=5) vezes1++;
		else{
			if(vetor[i]>=6 && vetor[i]<=10) vezes2++;
			else{
				if(vetor[i]>=11 && vetor[i]<=15) vezes3++;
				else{
					if(vetor[i]>=16 && vetor[i]<=20) vezes4++;
				}
			}
		}
	}
	diferenca=maior-menor;
	if(vezes1>maior2){
		maior2=vezes1;
		final="[1,5]";
	}
	if(vezes2>maior2){
		maior2=vezes2;
		final="[6,10]";
	}
	if(vezes3>maior2){
		maior2=vezes3;
		final="[11,15]";
	}
	if(vezes4>maior2){
		maior2=vezes4;
		final="[16,20]";
	}
	cout<<diferenca<<endl;
	cout<<"[1,5]="<<vezes1<<endl;
	cout<<"[6,10]="<<vezes2<<endl;
	cout<<"[11,15]="<<vezes3<<endl;
	cout<<"[16,20]="<<vezes4<<endl;
	cout<<final<<endl;

	return 0;
}

