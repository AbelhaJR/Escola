#include <iostream>
#include <iomanip>
using namespace std;

int 

int main()
{
	int pontoPx,pontoPy,vertice1x,vertice1y,vertice2x,vertice2y;
	cin>>pontoPx;
	cin>>pontoPy;
	cin>>vertice1x;
	cin>>vertice1y;
	cin>>vertice2x;
	cin>>vertice2y;
	if(pontoPx>vertice1x && pontoPx<vertice2x && pontoPy>vertice1y && pontoPy<vertice2y){
		cout<<1;
	}
	else{
		cout<<0;
	}
	
	return 0;
}
