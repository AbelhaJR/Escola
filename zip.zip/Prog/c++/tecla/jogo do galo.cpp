#include <iostream>
#include <math.h>

using namespace std;

int main()
{	
	int numero,i=1,c,produto;
	while(numero>i){
		produto=i*(i+1)*(i+2);
		if(produto==numero){
			c=1;
			break;
		}
	}
	if(c==1) cout<<"E TRIANGULAR"<<endl;
	else cout<<"NAO E TRIANGULAR"<<endl;
	return 0;
}

