#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;

int main()
{
	int maximo,minimo,digitos,maior=-9,menor=9999,soma=0,ola,i,numero;
	cin>>minimo;
	cin>>maximo;
	cin>>digitos;
	for(i=minimo;i<=maximo;i++){
		ola=i;
		while(ola>0){
			numero=ola%10;
			soma+=numero;
			ola=ola/10;
		}
		if(soma==digitos){
			if(i<menor) menor=i;
			if(i>maior) maior=i;
		}
		soma=0;
	}
	cout<<menor<<endl;
	cout<<maior<<endl;
	return 0;
}

