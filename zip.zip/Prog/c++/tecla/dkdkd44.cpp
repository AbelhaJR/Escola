#include <iostream>
#include <algorithm>
#include <iomanip>
#include <math.h>

using namespace std;
int i=0;
int j=0;
int posicaox,posicaoy;
int tabuleiro[3][3];
int resultados(int vitorias,int espacoslivres){
	if(vitorias==2 && espacoslivres==1){
		return 1;
	}
	else{
		return 0;
	}
}
int verificar(int nextPlayer){
	int vitorias=0,espacoslivres=0,ola;
	for(i=0;i<3;i++){
		
		vitorias=0;
		espacoslivres=0;
		for(j=0;j<3;j++){
			if(nextPlayer==tabuleiro[i][j]){
				vitorias++;
			}
			else{
				if(tabuleiro[i][j]==0){
					espacoslivres++;
					posicaox=i;
					posicaoy=j;
				}
			}
			ola=resultados(vitorias,espacoslivres);
			if(ola==1){
				return 1;
			}
		}
	}
	for(i=0;i<3;i++){
		vitorias=0;
		espacoslivres=0;
		for( j=0;j<3;j++){
			if(nextPlayer=tabuleiro[j][i]){
				vitorias++;
			}
			else{
				if(tabuleiro[j][i]==0){
					espacoslivres++;
					posicaox=i;
					posicaoy=j;
				}
			}
			ola=resultados(vitorias,espacoslivres);
		}
		if(ola==1){
			return 1;
		}
	}
	i=0;
	espacoslivres=0;
	vitorias=0;
	for(i=0;i<3;i++){
		if(nextPlayer==tabuleiro[i][i]){
			vitorias++;
		}
		else{
			if(tabuleiro[i][i]==0){
				espacoslivres++;
				posicaox=i;
				posicaoy=j;
			}
		}
	}
	ola=resultados(vitorias,espacoslivres);
	if(ola==1){
		return 1;
	}
	vitorias=0;
	espacoslivres=0;
	for(i=0;i<3;i++){
		j=2;
		if(nextPlayer==tabuleiro[i][j]){
			vitorias++;
		}
		else{
			if(tabuleiro[i][j]==0){
				espacoslivres++;
				posicaox=i;
				posicaoy=j;
			}
		}
	}
	ola=resultados(vitorias,espacoslivres);
	if(ola==1){
		return 1;
	}
	return 0;
	}

int main()
{	
	int nextPlayer,mano;
	cin>>nextPlayer;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			cin>>tabuleiro[i][j];
		}
	}
	mano=verificar(nextPlayer);
	if(mano==0){
		cout<<0;
	}
	else{
		cout<<posicaox+1<<" "<<posicaoy+1<<endl;
	}
	
	return 0;
}

