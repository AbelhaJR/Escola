#include <iostream>
using namespace std;


int main()
{
	int maxNumber,minNumber,digitos,sumOfDigits,sum=0,maior=-9,menor=999999,number;
	cin>>maxNumber;
	cin>>minNumber;
	cin>>sumOfDigits;
	for(int i=minNumber;i<=maxNumber;i++){
		number=i;
		while(number>0){
			digitos=number%10;
			sum=sum+number;
			number=number/10;
		}
		cout<<sum;
		if(sum==sumOfDigits){
			cout<<sum;
			if(i>maior) maior=i;
			if(i<menor) menor=i;
		}
		else{
			sum=0;
		}
	}
	cout<<menor<<endl;
	cout<<maior;
	return 0;
}

